# Noor Quran — PWA + Android (Capacitor)

## 1. Tester la version web (PWA)
1. Mettez tous les fichiers dans un dossier, ouvrez un terminal dedans.
2. `python3 -m http.server 8000`
3. Ouvrez http://localhost:8000 (« localhost » = l'ordinateur qui lance le serveur ; le téléphone ne peut pas l'atteindre ainsi).
4. Test hors ligne : F12 → Application → Service Workers (doit être « activated »). Ouvrez 2 sourates, cochez « Offline », rechargez : elles doivent s'afficher.
5. Sur téléphone : hébergez le dossier en HTTPS (GitHub Pages, Netlify), ouvrez le lien, puis « Ajouter à l'écran d'accueil ».

## 2. Obtenir l'APK (3 voies)
**A. GitHub Actions (le plus simple, rien à installer)**
1. Créez un dépôt GitHub (privé ou public), envoyez-y tout ce dossier.
2. Onglet Actions → « Build Android APK » → Run workflow. Attendez ~5-10 min.
3. Ouvrez l'exécution terminée → section Artifacts → téléchargez `noor-quran-debug-apk` (zip contenant `app-debug.apk`).

**B. Sur votre ordinateur** : installez Node 22+, JDK 21 et Android Studio (SDK Android).
`npm install` → `npm test` → `npm run build:www` → `npm run android:add` → `npm run icons` → `npm run apk:debug`.
APK : `android/app/build/outputs/apk/debug/app-debug.apk`.

**C. Android Studio** : `npm run sync`, puis `npx cap open android` → Build → Build APK(s).

## 3. Installer sur le téléphone
1. Transférez `app-debug.apk` (câble USB, Drive, e-mail à vous-même).
2. Ouvrez-le depuis le gestionnaire de fichiers ; autorisez « installer des applis inconnues » pour cette seule source, puis réactivez l'interdiction ensuite.
3. Installez uniquement un APK que vous avez compilé vous-même. Un APK de débogage n'est pas destiné au Play Store.

## 4. APK de publication signé
Créez un keystore (`keytool -genkey -v -keystore noor.jks -alias noor -keyalg RSA -keysize 2048 -validity 10000`), conservez-le HORS du dépôt (déjà dans .gitignore) avec ses mots de passe, puis Android Studio → Build → Generate Signed App Bundle / APK. Perdre le keystore empêche toute mise à jour.

## 5. Checklist de tests (à cocher sur appareil)
- [ ] Al-Fatiha : la basmala est le verset 1, sans doublon.
- [ ] Al-Baqara : basmala seule au-dessus, absente du début du verset 1.
- [ ] At-Tawba (9) : pas de basmala.
- [ ] Navigation sourate → verset, lien « Reprendre », retour arrière Android.
- [ ] Traduction : affichée / masquée, changement d'édition sur l'accueil.
- [ ] Audio : 2 récitateurs différents, verset suivant/précédent, enchaînement automatique.
- [ ] Favori et marque-page : ajout, présence dans « Mes listes », retrait.
- [ ] Recherche : un mot français puis un mot arabe ; un mot sans résultat.
- [ ] « Vérifier le texte » sur 3 sourates : lire le résultat, noter les écarts.
- [ ] Télécharger l'audio d'une sourate, mode avion, relire texte + audio.
- [ ] Lire quelques versets, fermer complètement l'app, rouvrir : progression conservée.
- [ ] Mode avion avant la première ouverture : message clair, pas de plantage.
- [ ] Rotation, grande police Android, mode sombre, TalkBack.

## 6. Audio en arrière-plan (APK)
L'APK embarque un lecteur Android natif (Media3/ExoPlayer, service de premier plan). Les fichiers sont dans `native/android/` et sont installés dans le projet Android par `scripts/patch-android.js` (lancé automatiquement par le workflow GitHub). Si vous compilez en local : `npm run apk:debug`.
La version web (PWA) continue d'utiliser le lecteur HTML. Hors connexion, l'APK utilise aussi le lecteur HTML (fichiers téléchargés).
